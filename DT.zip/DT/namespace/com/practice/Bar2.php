<?php
/*
* ファイルパス：C：¥xampp¥htdocs¥DT¥namespace¥com¥practice¥Bar2.php
* ファイル名：Bar2.php
*アクセスURL : http://localhost/Dt/namespace/com/practice/Bar2.php
*/
// ファイル空間を作る
namespace Com\Practice;
// useがあるとnamespaceがなくても動く、ただファイルの確認できるから書いた方がいい

require_once '../sample/Hoge.php';

use \Com\sample\Hoge;
// use:があると直接インポートできる、大事
//名前空間が違うが、useを使っているため呼び出す事ができる
//cf.Bar.php
$hoge = new Hoge;

class Bar{
  public function __construct()
  {
    echo "this is bar class<br>";
  }
}
