<?php

namespace album;

class Database_album
{
  //オートロードでファイルを読み込み、データベースのクラスを用いてインスタンス化
  private $db_con = null;
  private $db_host = 'localhost';
  private $db_user = 'album_user';
  private $db_pass = 'album_pass';
  private $db_name = 'album_db';

  public function __construct($db_host, $db_user, $db_pass, $db_name)
  {
    $this->db_con = $this->connectDB($db_host, $db_user, $db_pass, $db_name);
    $this->db_host = $db_host;
    $this->db_user = $db_user;
    $this->db_pass = $db_pass;
    $this->db_name = $db_name;
    // ＄thisとは自分のクラス自身を表す
    // ->クラスの中のメソッドや変数を呼び出す
  }

  private function connectDB($db_host, $db_user, $db_pass, $db_name)
  {
    $tmp_con = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    //mysqli_connect,MYSQLに接続する関数
    if($tmp_con !== false) {
      return $tmp_con;
    } else {
      printf("Connect failed: %s\n", mysqli_connect_error());
      exit();
    }
  } 

  public function execute($sql)
  {
    return mysqli_query($this->db_con, $sql);
  }

  public function select($sql) 
  {
    $res = $this->execute($sql);
    $data = [];//カラー配列用意
    while ($row = mysqli_fetch_array($res)) {
      array_push($data, $row);
    }
    //mysql_free_result($res);
    return $data;
  }
  //mysqli_fetch_assoc 配列にして値を返す

  public function quote($int)
  {
    return mysqli_real_escape_string($this->db_con,$int);
  }

  public function str_quote($str)
  {
    return "'" . mysqli_real_escape_string($this->db_con, $str) . "'";
  }
    // mysqli_real_escape_string:特殊文字を普通の文字列に変換

  public function getLastId()
  {
    return mysqli_insert_id($this->db_con);
  }

  public function close()
  {
    mysqli_close($this->db_con);
  }
}
// close　データベースを閉じる作業
