<?php
/**
 * ファイルパス : C: ¥htdocs¥DT¥get＼get.php
 * ファイル名 : get.php
 * アクセスURL : http://localhost/DT/get/get.php
 */
var_dump($_GET);
//$_GET : スーパグローバル変数(定義済み変数)の一つ。連想配列として使用する。

$data = [
  '渡辺',
  '佐藤',
  '田中'
  // 配列を定義
];
$id = (isset($_GET['id']) === true) ? $_GET['id']:'';

if($id !== "") echo $data[$id];
?>

<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>GETテスト</title>
</head>
<body>
  <p>
    <a href="http://localhost/DT/get/get.php?id=0">クリックすると渡辺さんが表示されます</a>
  </p>
    <a href="http://localhost/DT/get/get.php?id=1">クリックすると佐藤さんが表示されます</a>
  </p>
    <a href="http://localhost/DT/get/get.php?id=2">クリックすると田中さんが表示されます</a>
  </p>
</body>
</html>