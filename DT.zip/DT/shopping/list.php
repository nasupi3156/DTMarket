<?php
/*
*ファイルパス : C:\mamp\htdocs\DT\shopping\list.php
*ファイル名 : list.php(セッション関係のクラスファイル,Model)
*(商品一覧を表示するプログラム、Controller)
*アクセスURL : http://localhost/DT/shopping/list.php
*/
namespace shopping;

require_once dirname(__FILE__) . '/Bootstrap.class.php';

use shopping\Bootstrap;
use shopping\lib\PDODatabase;
use shopping\lib\Session;
use shopping\lib\Item;

// newで指定しているPDODatabaseは、PDODatabase.classのことです。
$db = new PDODatabase(Bootstrap::DB_HOST,Bootstrap::DB_USER, Bootstrap::DB_PASS, Bootstrap::DB_NAME, Bootstrap::DB_TYPE);
//DB_TYPE引数でPDODataのswitch文から
$ses = new Session($db);
$itm = new Item($db);

//テンプレート指定
$loader = new \Twig_Loader_Filesystem(Bootstrap:: TEMPLATE_DIR);
$twig = new \Twig_Environment($loader,[
  'cache' => Bootstrap::CACHE_DIR
]);

//SessionKeyを見て、DBへの登録状態をチェックする
//SessionのIDがあるかどうかを確かめている
$ses->checkSession();
$ctg_id = (isset($_GET['ctg_id']) === true && preg_match('/^[0-9]+$/' , $_GET['ctg_id']) === 1) ? $_GET['ctg_id']:'';

//カテゴリーリスト(一覧)を取得する
$cateArr = $itm->getCategoryList(); //category_id(cateArr)
//商品リストを取得する
$dataArr = $itm->getItemList($ctg_id);

// 配列は=はいらない
$context = [];
$context['cateArr'] = $cateArr; //category_id(cateArr)
$context['dataArr'] = $dataArr;
//twig表示処理
$template = $twig->loadTemplate('list.html.twig');
$template->display($context);