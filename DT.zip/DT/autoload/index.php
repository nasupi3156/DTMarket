<?php
/*
 *ファイルパス : C:\mamp\htdocs\DT\autoload\index.php
 *ファイル名 : index.php
 *アクセスURL : http://localhost/DT/autoload/index.php
 */

class ClassLoader
{
  public static function loadClass($class)
  // public static function でメソッドを定義
  {
    // $class = str_replace('\\','/',$class);
    require_once dirname(__FILE__).'/'.$class .'.class.php';
    //class.php ファイルを読み込む
  }
}
//これを実行しないとオートローダーとして動かない
spl_autoload_register([
  'ClassLoader',
  'loadClass'
  // メソッドを実行している
]);

$foo = new Foo();
$hoge = new Hoge();

// インスタンス化はnewクラス名を用いて、そのタイミングでインスタンス化が行われる

// fooやhogeが読み込まれる
// $foo = new Foo();
// $hoge = new Hoge();
// がClassLoaderで読み込まれる(実行される）

