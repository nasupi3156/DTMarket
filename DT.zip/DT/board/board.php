<?php
/*
*ファイルパス(win:):C:¥xampp¥DT¥function¥board.php
*ファイルパス(mac):/Applications/MAMP/htdocs/DT/board/board.php
*ファイル名:board.php
*アクセスURL:http://localhost/DT/board/board.php
*アクセスURL:http://localhost:8888/DT/board/board.php

今回の学習内容
・全体の流れ（ファイル読み込み　→ 投稿があったか確認 → 投稿があれば入力チェック　→ ファイルに書き込み）
・while構文
・外部データの取り扱い、ファイル操作
・インクリメント
*/

// 1:データの取得を行う
$data = '';

//$fpにはfopenの戻り値(ファイルハンドル)が入ってくる
// ファイルポインタを開く、ファイルと読み込みか書き込みか
// 引数(「◯◯してほしい」という依頼)はファイルとモード
$fp =fopen('data.txt','r');
//一行(1行)ずつファイルを読み込む
// 読み込みが終わるまでループを繰り返す
// 新規でdata.txtと、　data2.txtを作成してください・中身は空白でOK
$flg = true;
$count = 0;
while ($flg === true){
  //fgets() : 1行取得する、whileで回して全行取得
  $res = fgets($fp); 
  // var_dump($res); テキスト1行ずつ表示
  //  echo '<br>';

  if ($res === false) {  //ループしきるとfalse 
    $flg = false;
  }
  //↓ $data = $data(今までの書き込み全て) + $res
  // $a. $b　結合

  //1回目　：　$data = $res;
  //2回目　：　$data = $res; . $res;
  //3回目　：　$data = $res; . $res; . $res
  //4回目　：　$data = $res; $res; . $res; . $res;
  
  $data .= $res;  //連結させないとhtmlのechoで何も表示されていないよに見える。※正確には最後の行のnullが表示されている。
  // echo'<br>';
  
  $count++;
  if ($count % 2 === 0){ //2行分の出力ごとに<br>を行末につける。
     $data .= '<br>';
  }
  //var_dump($data); //  テキストが1個ずつ連結されていく
  //echo '<br>';
}

//しおりをしまう
fclose($fp);
//よりスマートな書き方はこれ↓
//while($res = fgets($fp)){
//  $data .= $res. "<br>";
//} 

//2：データの書き込みを行う
var_dump($_POST);

if(isset($_POST['send']) === true){
  $name = $_POST['name'];
  $comment = $_POST['comment'];
  
  if ($name !== '' && $comment !==''){
    // 追加書き（追記/後ろに書き込み）の場合モードはa、新規の上書きはw
    $fp = fopen('data.txt' , 'a');

    //LOCK_SH : 共有ロック(読み込みは可)
    // LOCK_EX : 排他的ロック（読み込みも書き込みも不可）、LOCK_UN:ロック解除
    //ファイルロック(自分の編集中は他者が書き込めな他者が書き込めないようにする)
    //flock : 自分がロック出来た場合は　→　LOCK_EXする
    if(flock($fp,LOCK_EX) === true){
      //fwrite:指定したモードで書き込み
      //fwrite(:指定したモードで書き込み)
      fwrite($fp,$name . "\n" . $comment. "¥n");//エスケープシーケンス: "¥n"　、　"¥n"   mac = \バックスラッシュ　 windows = ¥
      //ファイルロック解除(他ユーザーが書き込めるようになる)
      flock($fp, LOCK_UN);
    }
    fclose($fp);
    } else {
      echo '名前、またはコメントが記入させていません' ;
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="content-type" content="text/html;"charset="utf-8" />
  <title>掲示板</title>
</head>
<body>
  <form method="post" action="">名前 :
    <input type ="text" name = "name" value="">コメント:
    <!-- rows="" (入力欄の高さを行数で指定) -->
    <!-- cols="" (入力欄の幅を文字数で指定)-->
    <textarea name="comment" rows="8" cols="30"></textarea>
    <input type="submit" name="send" value="書き込む">
  </form>
    <!-- ここに書き込まれたデータを表示する -->
    <!-- 書き込まれたデータは一個遅れて表示される -->
    <!-- 一回読み込んでから表示させるため。リロードがsummitする -->
    <?php echo $data; ?>
</body>
</html>