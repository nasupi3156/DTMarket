<?php
/*
*ファイルパス : C:\mamp\htdocs\DT\shopping\lib\PDODatabase.class.php
*ファイル名 : PDODatabase.class.php(商品に関するプログラムのクラスファイル、Model)
*PDO(PHP Data Objects) : PHP標準(5.1.0以降)のDB接続クラス
*おすすめ記事:http://qiita.com/7968/items/6f089fec8dde676abb5b
*/

namespace shopping\lib;

class PDODatabase
{
  private $dbh = null;
  private $db_host = '';
  private $db_user = '';
  private $db_pass = '';
  private $db_name = '';
  private $db_type = '';
  private $order = '';
  private $limit = '';
  private $offset = '';
  private $groupby = '';

  public function __construct($db_host, $db_user, $db_pass, $db_name, $db_type)
  {
    $this->dbh = $this->connectDB($db_host, $db_user, $db_pass, $db_name, $db_type);
    $this->db_host = $db_host;
    $this->db_user = $db_user;
    $this->db_pass = $db_pass;
    $this->db_name = $db_name;
    //SQL関連
    $this->order = '';
    $this->limit = '';
    $this->offset = '';
    $this->groupby = '';
    // コンストラクタ内で、これらの情報を $this を使ってクラス内のプロパティに保存,$thisはプロパティ、メソッドアクセスできる
  }
  // connectDBの中でMYSQLを使う
  private function connectDB($db_host, $db_user, $db_pass, $db_name, $db_type)
  {
  
  try
  {
      //接続エラー発生 → PDOExceptionオブジェクトがスローされる → 例外処理をキャッチする
    switch ($db_type) {
      //データベースに接続する処理をここで書いている
      case 'mysql':
        $dsn = 'mysql:host=' . $db_host . ';dbname=' . $db_name;
        $dbh = new \PDO($dsn, $db_user, $db_pass);  
        // ＼PDO元々用意されてる
        // \PDOインスタンス化
        $dbh->query('SET NAMES utf8');//文字コード指定
        break;

      case 'pgsql': //今回はこれは使われない
        $dsn = 'pgsql:dbname=' . $db_name . ' host=' . $db_host . ' port=5432';  //5432
        $dbh = new \PDO($dsn, $db_user, $db_pass);
    break;
    // \PDO クラス
  }
} catch (\PDOException $e) {
    var_dump($e->getMessage());
    exit();
} // エラーになった時の処理を書いている

  return $dbh;
}

public function setQuery($query = '', $arrVal = [])
{
  $stmt = $this->dbh->prepare($query);
  $stmt->execute($arrVal);
}
// prepareしたらexecuteしてsql文(全体)を実行する流れを覚える


//session 47行目
// $table = 'session';
// $col = 'customer_no';
// $where = 'session_key = ?';
// $arrVal = '[$this->session_key]';
//わからない時は、コピーしてみる


// item商品リスト取得
public function select($table, $column = 
// クラス内の関数はメソッド select
'', $where = '', $arrVal = [])
{
  // getsqlメソッドを実行している
  // $thisはインスタンス自身を指している
  $sql = $this->getSql('select', $table, $where, $column);
  //getsql、sql文の作成
  // $sql .= '';
  
  $this->sqlLogInfo($sql, $arrVal);
  // ↑sqlじゃなくて$this
  $stmt = $this->dbh->prepare($sql);
  $res = $stmt->execute($arrVal);
  
  if ($res === false) {
    $this->catchError($stmt->errorInfo());
  }

  //データを連想配列に格納
  $data = [];
  while ($result = $stmt->fetch(\PDO::FETCH_ASSOC)) {
    array_push($data, $result);
    //ここで多次元配列
  }
  return $data;
}

public function count($table, $where = '', $arrVal = [])
{
  $sql = $this->getSql('count', $table, $where);

  $this->sqlLogInfo($sql, $arrVal);

  $stmt = $this->dbh->prepare($sql);

  $res = $stmt->execute($arrVal);

  if($res === false) {
    $this->catchError($stmt->errorInfo());
  }
  $result = $stmt->fetch(\PDO::FETCH_ASSOC);

  return intval($result['NUM']);
  // intval数値型にする
}

public function setOrder($order = '')
{
  if ($order !== '') {
    $this->order = ' ORDER BY ' . $order;
    // orderサイドのドット入れるのか、見本は「,」両方ともエラーが出る
    // $orderに;でエラーが解消
  }
}

public function setLimitOff($limit = '', $offset = '')
{
  if ($limit !== "") {
    $this->limit = " LIMIT " . $limit;
  }
  if($offset !== "") {
    $this->offset = " OFFSET " . $offset;
  }
}

public function setGroupBy($groupby)
{
  if ($groupby !== "") {
    $this->groupby = ' GROUP BY ' . $groupby;
  }
}
  
// getsqlでとってきたもの(89行目)selectが入ってるから
// switchの($type)にはselectが入っる
private function getSql($type, $table, $where = '', $column = '')                            
// $column左サイドの''入れ忘れでエラー
{
switch($type) {
case 'select':
      
   $columnKey = ($column !== '') ? $column : "*";
     //三項演算子
   break;
     
   // ($column !== '') ? $column:"*"三項演算子で*を入れている;
 case 'count':
    
      $columnKey = 'COUNT(*) AS NUM ';
   break;

      default: //当てはまらなかったら
        break;
  }

  $whereSQL = ($where !== '') ? ' WHERE ' . $where : '';
  $other = $this->groupby . "  " . $this->order . "  " . $this->limit . "  " . $this->offset;

  //sql文の作成
  $sql = " SELECT " . $columnKey . " FROM " . $table . $whereSQL . $other;
    return $sql;
    // $sqlを返す
}

public function insert($table, $insData = [])
{
  $insDataKey = [];
  $insDataVal = [];
  $preCnt = [];
  
  $columns = '';
  $preSt = '';
  
  // cart.classのinsData 24
  foreach ($insData as $col => $val) {
    $insDataKey[] = $col; //[$customer_no, $item_id]
    $insDataVal[] = $val; //[$customer_no, $item_id]
    $preCnt[] = '?';  //[?, ?]
    // 配列に?しか入れてない
  }

  $columns = implode(",", $insDataKey);//'customer_no, item_id' // implode : 配列を文字列
  
  $preSt = implode(",", $preCnt); //'?, ?'この配列を文字列にしています
  //implode配列を文字列にする
  // sql文を作り実行宣言
  $sql = " INSERT INTO "
    . $table. " ("             //cart
    . $columns. ") VALUES ("   //$customer_no, $item_id
    . $preSt                   //'?, ?'
    . ") ";
  // INSERT INTO cart (customer_no, item_id) VALUES (?,?) こういったINSERT INTO文が作られた

  $this->sqlLogInfo($sql, $insDataVal);

  $stmt = $this->dbh->prepare($sql); //INSERT INTO実行準備

  $res = $stmt->execute($insDataVal); //実行 ここには引数[$customer_no, $item_id]  ?, ? に入る

  if ($res === false) {
    $this->catchError($stmt->errorInfo());
  }

  return $res;
}

// updeteの引数の中の$where = '', $insData = []の位置が逆でずっとエラー
public function update($table, $insData = [], $where = '', $arrWhereVal = [])
{
  $arrPreSt = [];
  // 配列
  foreach ($insData as $col => $val) {
    $arrPreSt[] = $col . " =?";
    //prepared Statementの準備、予測できれば良い
  } 
  $preSt = implode(',', $arrPreSt);
  //prrPreStをimplodeします
  //implode配列を文字列にする

  //sql文の作成
  $sql = " UPDATE "
    . $table
    . " SET "
    . $preSt
    . " WHERE "
    . $where;
  
    // cart id情報
  $updateData = array_merge(array_values($insData), $arrWhereVal);
  //array_merge配列を結合する関数
  //array_values配列から値だけ取り出す関数
  $this->sqlLogInfo($sql, $updateData);

  $stmt = $this->dbh->prepare($sql);
  $res = $stmt->execute($updateData);

  if($res === false) {
    $this->catchError($stmt->errorInfo());
  }
  return $res;
}

public function getLastId()
{
  return $this->dbh->lastInsertId();
  //lastInsertId、PDOで元々用意されてるメソッド
  //最後にデータベースに印刷されたID情報をとってくることが出来る、PDOで用意されたメソッド
}

private function catchError($errArr = [])
{
  $errMsg = (!empty($errArr[2]))? $errArr[2]:"";
  die("SQLエラーが発生しました。" . $errArr[2]);
} 
// .$errMsg  .$errArr[2] 授業では$errMsgでもOKだった

private function makeLogFile()
//ファイルがない場合、ディレクトリ作って、このファイル作ることをmakeLogFileでやっている
{ 
  $logDir = dirname(__DIR__) . "/logs";
  if (!file_exists($logDir)) {
    mkdir($logDir, 0777);
  }
   //file_exists : ファイルがあるかどうかを調べる関数
   //ファイルがない場合ディレクトリを作りファイルを作りますよ
   //  っていうのをやってる。上下で
   //0777、リナックスコマンド:権限を付与
   // デフォルトで0777が入る
  
    $logPath = $logDir . '/shopping.log';
  if(!file_exists($logPath)) {
    touch($logPath);
  }
  return $logPath;
}

// メソッド内で定義
private function sqlLogInfo($str, $arrVal = [])
{
  // $this->makeLogFile();を $logPathに入れてる?
  // $logPathは
  $logPath = $this->makeLogFile();
  $logData = sprintf("[SQL_LOG:%s]: %s [%s]\n", date('Y-m-d H:i:s'), $str, implode(",", $arrVal));
  error_log($logData, 3, $logPath);
  }
}
//最後のメソッドはlogsのフォルダーの中のshopping.logのsqlのログを格納処理をしている