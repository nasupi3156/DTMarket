<?php

namespace ch;

class Database
{
  private $db_con = null;
  private $db_host = '';
  private $db_user = '';
  private $db_pass = '';
  private $db_name = '';
  // クラス名の関数
  // __construct : アンダースコアは2つ

  public function __construct($db_host, $db_user, $db_pass, $db_name)
  {
    $this->db_con = $this->connectDB($db_host, $db_user, $db_pass, $db_name);
    // db_con,connectDB : データベースに接続した情報
    // $this->db_conに代入され、それがprivate $db_con = null;などのプロパティーに代入
    $this->db_host = $db_host;
    $this->db_user = $db_user;
    $this->db_pass = $db_pass;
    $this->db_name = $db_name;
  }

  // connectDB: データベースに接続する行動
  private function connectDB($db_host, $db_user, $db_pass, $db_name)
  {
    $tmp_con = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
//mysqlに接続

    if ($tmp_con !== false) {
      return $tmp_con;
    } else {
      printf("Connect failed: %s\n" , mysqli_connect_error());
      exit();
    }
  }

public function execute($sql)
{
  //書き方違う
  return mysqli_query($this->db_con, $sql);
  // mysqli_query : query文を実行する関数
  // 最初の引数にデータベース情報を入れて(db_con)実際入れこむ$sql文をここでとってきている
}

public function select($sql) //関数
{
  $res = $this->execute($sql);
  $data = [];
  while($row = mysqli_fetch_assoc($res)) {
    // データベースに保存された値を(テーブル)見やすく使いやすく整理してくれる
    array_push($data, $row);
    // mysqli_fetch_assoc : 配列で値を返す
    // mysqli_fetch_arrayにしていた、正しくはassoc?
  }
  //mysql_free_result($res);
  return $data;
}

public function quote($int)
{
  return mysqli_real_escape_string($this->db_con, $int);
}

public function str_quote($str)
{
  return "'" .mysqli_real_escape_string($this->db_con, $str) . "'";
}

public function getLastId()
{
  return mysqli_insert_id($this->db_con);
}

public function close()
{
  mysqli_close($this->db_con); 
}
}