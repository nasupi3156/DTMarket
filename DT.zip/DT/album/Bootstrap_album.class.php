<?php

namespace album;

require_once dirname(__FILE__) .'./../vendor/autoload.php';

class Bootstrap_album
{
  //定数が定義されてる
  // 定数は自動的にpublicがつく public constと同じ意味

  const DB_HOST = 'localhost';
  // データベースの場所は 'localhost' だよ」という情報を箱に入れている
  const DB_NAME = 'album_db';
  const DB_USER = 'album_user';
  const DB_PASS = 'album_user';

  const APP_DIR = '/Applications/MAMP/htdocs/DT/';
  // ファイルパス(何のため？)
  // APP_DIRファイルやテンプレートの場所を教えている箱
  //この二つを連結,APP_DIR  TEMPLATE_DIR(templateじゃなくてbird) 
  const TEMPLATE_DIR = self::APP_DIR . 'templates/album/';
  //TEMPLATE_DIRプログラムの場所を教えています。

  const CACHE_DIR = false;
  // 写経では下記
  // const CACHE_DIR = self::APP_DIR . 'template_c/border(album)/';
  // 開発段階ではfalse,キャッシュによる不具合を防ぐため

  public static function loadClass($class) 
  {
    $path = str_replace('\\', '/', self::APP_DIR .$class . '.class.php');
    require_once $path;
  }
}
    //str_replaceとは、特殊文字を変換、
    //バックスラッシュ(\\)をスラッシュ(/)にする
    //引数が($classに入る)でautoloadで実行
    // str_replace()関数は、文字列を置換する関数
    // 置換(あるものを他のものに置き換えること。
    //self::APP_DIR はアプリケーションのディレクトリを表し、クラス名と .class.php を連結して、クラスのファイルパスを生成します。
    //こちらにデータベースが入り情報をとってこれる
    //('\\', '/', self::APP_DIR . $class . '.class.php');ここでとってきたファイル名をデータベースで読み込める処理を行える

//これを実行しないとオートローダーとして動かない
spl_autoload_register([
  'album\Bootstrap_album', 
  'loadClass'
]);