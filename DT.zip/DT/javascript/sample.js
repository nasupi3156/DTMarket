function button_click(){
  alert('クリック');
}
function button_check(){
  //変数を定義 cf.php $name
  //name_idの要素を取得
  //<input id ="name_id type="text" name="name" value="">をnameElementに代入
  var nameElement = document.getElementById('name_id');

  //nameElement.value :入力フォームに入れた値
var name = nameElement.value;
console.log(name);
// 検証コンソールで確認にはcon.log
  if(name === ''){
    alert('名前が入力されていません');
} else {
  var writeElement = document.getElementById('write')
  writeElement.innerHTML = name;
  alert('入力された名前は' + name + 'です');
}
}

// varは変数を表してる、phpでいうnullと同じ
// var nameElement ではnameElementが変数
// javascriptで変数を扱うには、varなどを使う