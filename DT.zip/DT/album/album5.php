<?php

// borad5.php

namespace album;

require_once dirname(__FILE__) . '/Bootstrap_album.class.php';

use album\Bootstrap_album;
// useでalbumのBootstrapを使う

$db = new Database_album(Bootstrap_album::DB_HOST, Bootstrap_album::DB_USER, Bootstrap_album::DB_PASS, Bootstrap_album::DB_NAME);
// 静的メソッドで定数

//Twigを表示するための設定(Twigファイルの配置場所や、キャッシュファイルの保存場所を指定。)
$loader = new \Twig_Loader_Filesystem(Bootstrap_album::TEMPLATE_DIR);
$twig = new \Twig_Environment($loader, [
  'cache' => Bootstrap_album::CACHE_DIR
]);


$msg = '';
$err_msg = '';
if (isset($_POST['send']) === true) {
  $name = $_POST['name'];
  $contents = $_POST['contents'];

  if ($name !== '' && $contents !== '') {
    // データベースに挿入する際のSQL文のINSERT INTOを作成している、albumテーブル名、カラムname,contents、VALUESは下の値をを入れる
    $query = " INSERT INTO album ("
        . " name, "
        . " contents "
        . ") VALUES ("
        .$db->str_quote($name) . ","
        .$db->str_quote($contents).")";
        
    $res = $db->execute($query);

    if ($res !== false) {
      $msg = '書き込みに成功しました';
     } else {
      $err_msg = '書き込みに失敗しました';
     }
  } else {
    $err_msg = '名前とコメントを記入してください';
  }
}
  //sql文を作ってるだけ
  $query = " SELECT "
  . " id, "
  . " name, "
  . " contents "
  . " FROM "
  . " album ";
  
  //$dataにはデータベースからとってきた情報が入っている
  $data = $db->select($query);
  $db->close();

  //変数の設定
  $context = [];
  $context['msg'] = $msg;
  $context['err_msg'] = $err_msg;
  $context['data'] = $data;
  //$data データベースからとってきた情報入ってる

  //データ(context)を渡して、指定したTwigファイル(album5.html.twig)を表示
  $template = $twig->loadTemplate('album5.html.twig');
  $template->display($context);
  
  // 下記のような記述でも良い
  // echo $twig->render('.html.twig' , $context);
  // twigは出力する値を配列のキー名として入れる。twig上ではキー名を使って値を取り出せる