<?php
/*
*ファイルパス : C:\mamp\htdocs\DT\member\regist.php
*ファイル名 : regist.php
*アクセスURL : http://localhost/DT/member/regist.php
*/
namespace member;

require_once dirname(__FILE__) . '/Bootstrap.class.php';

use member\master\initMaster;
use member\Bootstrap;

//テンプレート指定
// twig使うためのテンプレート
$loader = new \Twig\Loader\FilesystemLoader(Bootstrap::TEMPLATE_DIR);
$twig = new \Twig\Environment($loader,[
  'cache' => Bootstrap::CACHE_DIR
]);

//初期データを設定
//errArrの配列を作っている
$dataArr = [
  'family_name' =>'',
  'first_name' => '',
  'family_name_kana' => '' ,
  'first_name_kana' => '',
  'sex' => '',
  'year' => '',
  'month' => '',
  'day' => '',
  'zip1' => '',
  'zip2' => '',
  'address' => '',
  'email' => '',
  'tel1' => '',
  'tel2' => '',
  'tel3' => '',
  'traffic' => '',
  'contents' => '' 
];


// 上記のdataArrと同じ形でerrArrも書くことも出来るが長くなるのでforeach文でdataArrと同じ事errArrでしている、つまりここで上記のdataArrと同じ構造を作った
//エラーメッセージの定義、初期
$errArr = [];
foreach($dataArr as $key => $value){
  $errArr[$key] ='';
}

//array($yearArr,$monthArr,$dayArr)初日の補足
//静的クラス
// $yearArr = '';
// $monthArr = '';
// $dayArr = '';
// これを一括してやってくれている
list($yearArr, $monthArr, $dayArr) = initMaster::getDate();
// list : 右辺の配列の要素を、左辺の変数に代入する事ができる
$sexArr = initMaster::getSex();
$trafficArr = initMaster::getTrafficWay();

// キーを指定して配列を入れている
// getTrafficWayの配列がここでとってこれています
$context = [];

$context['yearArr'] = $yearArr;
$context['monthArr'] = $monthArr;
$context['dayArr'] = $dayArr;
$context['sexArr'] = $sexArr;
// $context['trafficArr'] = $trafficArr;

$context['dataArr'] = $dataArr;
$context['errArr'] = $errArr;

// 出力をする処理 : この場合はregist.twigに
$template = $twig->loadTemplate('regist.html.twig');
$template->display($context);