<?php

// 設定に関するプログラム

namespace ch;
//(__FILE__)現在のディレクトリ / ライブラリーはインストールしphp内で使う時それぞれのライブラリーをphpの中で読み込む必要がある、それがrequireだけどめんどくさいのでautoload.phpを読み込めば、それぞれのライブラリをphp内で使える仕組み
require_once dirname(__FILE__) . './../vendor/autoload.php';

class Bootstrap
{
  const DB_HOST = 'localhost';
//定数は暗黙的にpublicが付けられる
  const DB_NAME = 'ch_db';
  
  const DB_USER = 'ch_user';

  const DB_PASS = 'ch_pass';

// macユーザ
const APP_DIR = '/Applications/MAMP/htdocs/DT/';
const TEMPLATE_DIR = self::APP_DIR . 'templates/ch';
//const CACHE_DIR = false;

// const CACHE_DIR self::APP_DIR . 'templates_c/board';
  //開発段階ではfalse,キャッシュによる不具合を防ぐため

const CACHE_DIR = false;
 //const TEMPLATE_DIR = self::APP_DIR . 'templates_c/board/';
  //開発段階ではfalse,キャッシュによる不具合を防ぐため

// public static function loadClass($class)
// {
//   $path = str_replace('\\','/',self::APP_DIR .'.class.php');
//   require_once $path;
// }  
// オートロードが実行されるタイミングで上記にdatabaseという物が入りdatabaseのprivate nullなどがとってこれる
//str_replaceは特殊文字を変換、エスケープシークエンス
//  \(バックスラッシュ)をスラッシュにするのをしている


public static function loadClass($class)
{
  $classWithoutNamespace = preg_replace('/\\\\/', '/', $class);
  $path = self::APP_DIR . $classWithoutNamespace . '.php';
  require_once $path;
}


}
//これを実行しないとオートローダーとして動かない
spl_autoload_register([
  'ch\Bootstrap',  //クラス名
  'loadClass'     //メソッド名を使ってクラスを読み込む
]);

// Twigの初期化
$loader = new \Twig\Loader\FilesystemLoader(Bootstrap::TEMPLATE_DIR);
$twig = new \Twig\Environment($loader);

// Twigテンプレートの読み込みとレンダリングの例
$template = $twig->load('7ch.html.twig');
echo $template->render(['variable' => 'value']);