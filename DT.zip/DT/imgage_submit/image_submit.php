<?php
/*
*ファイルパス(win:):C:¥xampp¥DT¥csv¥csv.php
*ファイルパス(mac):/Applications/MAMP/htdocs/DT/csv/csv.php
*ファイル名:csv.php
*アクセスURL(Win):http://localhost/DT/csv/csv.php
*アクセスURL:http://localhost:8888/DT/csv/csv.php
*今回の学習内容
*・全体の流れ(投稿があったか確認　→ 画像のエラーチェック → 画像のアップロード)
*・画像のファイル情報
*/

var_dump($_POST) ; echo '<br><br>';

//送信ボタンが押させているかどうか
if(isset($_POST['send']) === true) {
  var_dump($_FILES) ; echo '<br><br>'; 
  // $FILES[] : 連想配列で返す
  $tmp_image = $_FILES['image']; //[]はinputのname属性で指定した名前
  //　var_dump($tmp_image) ; echo '<br><br>'; // $_FILES['image']だけ抜いて扱いやすくする
  //　エラーがなく、サイズが0ではないか
  if($tmp_image['error'] === 0 && $tmp_image['size'] !==0){
  //正しくサーバにアップさせているかどうか
  // is_uploaded_file : HTTP POSTでアップさせたか調べる
  if (is_uploaded_file($tmp_image['tmp_name']) === true){
    //画像情報を取得する。getimagesize : 画像のサイズ取得、mime他7つの値を連想配列で返す
    //なぜ、getimagesizeを使うのか？実際の画像を解析して、mimeを取得する。$_FILESはファイル名から判断して出力したmimeを出しているので改竄が可能
   
    $image_info = getimagesize($tmp_image['tmp_name']);
   
    //var_dump($image_info) ; echo '<br><br>';
    //MIME(マイム) : 漢字(2バイト文字)や画像、音声を、半角英数字データ(文字列)に、変換して転送する。

    $image_mime = $image_info['mime'];
    //画像サイズが利用できるサイズ内容かどうか
  if ($tmp_image['size'] > 1048576){
  echo 'アップロードできる画像のサイズは、1MBまでです';
  //画像の形式が利用できるタイプかどうか
  } elseif (preg_match('/^image \/jpeg$/' , $image_mime) === 0){
    echo 'アップロードできる画像の形式は、JPEG形式だけです';
    //move_uploaded_file(ファイル名、名前) : アップさせたファイルを新しい位置に移動させる。第二引数でディレクトリ&名前を指定。
  }
  //time : 現在時刻をUnixエポック(1970年1月1日00:00:00GMT)からの通算秒として返す(Unixタイムスタンプ)
}  elseif (move_uploaded_file($tmp_image['tmp_name'],'./upload_' . time() . '.jpg') === true) {
  echo '画像のアップロードが完了しました';
      }
    }
  }


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>画像アップロード</title>
</head>
<body>
  <!--ファイルのアップロードにはenctype="multipart/form-data"が必要 -->
  <form method ="post" action="" enctype="multipart/form-data">
    <input type="file" name="image"> <input type="submit" name="send" value="送信">

    <!-- multipart/form-data = ファイルアップロードでこれが必要
    ファイル自体は何でもいい
   -->
</body>
</html>