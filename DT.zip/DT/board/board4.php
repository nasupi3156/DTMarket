<?php
/*
*ファイルパス :C:¥xampp¥DT¥function¥board4.php
*ファイルパス(mac):/Applications/MAMP/htdocs/DT/board/board4.php
*ファイル名:board4.php
*アクセスURL: http://localhost/DT/board/board4.php
*学習内容 : データの投入
 */

 $db_host = 'localhost';
 $db_name = 'board_db';
 $db_user = 'board_user';
 $db_pass = 'board_pass';

 //データベースへ接続する
 $link = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
 
 if($link !== false) {
    $msg = '';
    $err_msg = '';

    if(isset($_POST['send']) === true) {
      $name = $_POST['name'];
      $contents = $_POST['contents'];
      
      if($name !=='' && $contents !==''){
        //!=='' 空(カラ)ではない

        //$query = "INSERT INTO board(name,contents) VALUEES("," mysqli_real_escape_string($name ・・・
        //改行を入れる時は .(ドット)で繋ぐ
        //$var = "a". "b"
        // $var = "a"
        // ."b"
        $query = "INSERT INTO board ("
        ."  name, "
        ."  contents "
        .") VALUES ("
        ."'" . mysqli_real_escape_string($link, $name). "', "
        ."'" . mysqli_real_escape_string($link, $contents). "'"
        .")";

        $res = mysqli_query($link, $query);
        // ↑ $res = mysqli_query("insert into・・・");
        //mysql_query　クエリを実行する
        if($res !== false){
          $msg = '書き込みに成功しました';
        } else {
          $err_msg = '書き込みに失敗しました';
        }
        } else {
          $err_msg = '名前とコメントを入力してください';
        }

      }
      
      $query = "SELECT id, name, contents FROM board";
      $res = mysqli_query($link, $query);
      $data = [];
      while($row = mysqli_fetch_assoc($res)){
        array_push($data, $row);
      }

      arsort($data);
     //arsort 降順(逆順)で表示
    } else {
      echo 'データベースへの接続に失敗しました';
    }
    //データベースへの接続を閉じる
    mysqli_close($link);
  
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
  <form method = "post" action="">
  名前<input type = "text" name="name" value="">コメント
  <textarea name="contents" rows="4" cols="20"></textarea>
  <input type ="submit" name="send" value="書き込む">
  </form>
  <! -- ここに、書き込まれたデータを表示する -->
 
<?php
 if($msg  !== ''){
  echo '<p>' . $msg. '</p>';
}
if($err_msg !==''){
  echo '<p style ="color:#f00">'  . $err_msg. '</p>';
}
foreach ($data as $key => $val){
  echo $val['name']. '' . $val['contents']. '<br>';
}
?>  
</body>
</html>