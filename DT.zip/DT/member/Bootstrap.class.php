<?php
/*
*ファイルパス : C:\mamp\htdocs\DT\member\bootstrap.class.php
*ファイル名 : Bootstrap.class.php(設定に関するプログラム)
*/
namespace member;

require_once dirname(__FILE__) . './../vendor/autoload.php';
// XAMPPの場合 require_once dirname(__FILE__) .'/..vendor/autoload.php';ではないと正常に作動しない。

class Bootstrap
{
  // データベース接続情報
  const DB_HOST = 'localhost';
  // データベースの場所(サーバー名)　
  const DB_NAME = 'member_db';
  // データベースの名前
  const DB_USER = 'member_user';
  // データベースアクセスするユーザ名
  const DB_PASS = 'member_pass';
  //データベースにアクセスするためのパスワード 　 
  
  // アプリケーションのディレクトリとURLの設定
  const APP_DIR = '/Applications/MAMP/htdocs/DT/';
  // アプリケーションのフォルダのパス
  
  const TEMPLATE_DIR = self::APP_DIR. 'templates/member/';
  // テンプレートファイルのパス
  
  const CACHE_DIR = false;
  //const CACHE_DIR = self::APP_DIR.'templates_c/member/';
  // キャッシュのフォルダのパス（キャッシュを使わない）
  
  const APP_URL = 'http://localhost/DT/';
  // アプリケーションのURL
  const ENTRY_URL = self::APP_URL . 'member/';
  // メンバーのページへのURL
  //ここの二つの値が、common.jsのvar entry_url = $('#entry_url').val();入った。
  
  public static function loadClass($class)
  {
    $path = str_replace('\\','/',self::APP_DIR . $class . '.class.php');
require_once $path;
    // ここに実際の読み込む処理を追加する必要があります
  }
}

spl_autoload_register([
  'member\Bootstrap',
  'loadClass'
]);
// このコードは、ウェブアプリケーションの設定情報をまとめて管理するためのプログラムです。