<?php
/*
* ファイルパス：C：¥xampp¥htdocs¥DT¥namespace¥com¥sample¥Hoge.php
* ファイル名：Hoge.php
*/
namespace Com\Sample;

class Hoge
{
  public function __construct()
  {
    echo "this is hoge class<br>";
  }
}

