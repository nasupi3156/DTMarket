<?php
/*
*ファイルパス(win:):C:¥xampp¥DT¥function¥board3.php
*ファイルパス(mac):/Applications/MAMP/htdocs/DT/board/board3.php
*ファイル名:board3.php
*アクセスURL(Win):http://localhost/DT/board/board3.php
*学習内容 : データベース(MySQL/MariaDB)との接続
*/

$db_host = 'localhost';
$db_name = 'board_db';
$db_user = 'board_user';
$db_pass = 'board_pass';
//これらの情報を変数に格納している

//データベースホストへ接続する
$link = mysqli_connect($db_host, $db_user, $db_pass,$db_name);
// echo '<pre>'; var_dump($link); echo'</pre>';
if($link !== false){
  $query = "SELECT id, name, contents FROM board";
  $res = mysqli_query($link, $query);
  // echo '<pre>'; var_dump($res); echo'</pre>';
  $data = [];
  //結果を配列に格納する
  while ($row = mysqli_fetch_assoc($res))
  {
    // echo '<pre>'; var_dump($row); echo'</pre>';
    //$lineArray3[] = $lineArray2;
    $data[] = $row;
    //array_push($resArr.$row);
    //下記は上記と同じ動作
  }
  // echo '<pre>'; var_dump($data); echo'</pre>';
  arsort($data);
  //arsort(エーアールソート) : 降順(逆順)で表示
} else {
  echo "データベースの接続に失敗しました";
}
//データベースへの接続を閉じる
mysqli_close($link);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>掲示板</title>
</head>
<body>
  <form method="post" action="">
    名前 <input type="text" name="name" value="">コメント
    <textarea name="contents" cols="20" rows="4"></textarea>
    <input type="submit" name="send" value="書き込む">
  </form>

  <!-- ここに、書き込まれたデータを表示する -->

  <?php
    echo 'id : name:contents <br>';
    //  echo '<pre>'; var_dump($data); echo'</pre>';
    foreach ($data as $val){
      echo $val['id'] . $val['name']. '' . $val['contents'] . '<br>';
    }
  ?>
</body>
</html>