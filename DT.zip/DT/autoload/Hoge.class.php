<?php
/*
 *ファイルパス : C:\mamp\htdocs\DT\autoload\Hoge.class.php
 *ファイル名 : Hoge.class.php
 */

 class Hoge{
  public function __construct()
  {
    echo "Hoge<br>";
  }
 }
 