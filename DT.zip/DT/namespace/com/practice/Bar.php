<?php
/*
* ファイルパス：C：¥xampp¥htdocs¥DT¥namespace¥com¥practice¥Bar.php
* ファイル名：Bar.php
*アクセスURL : http://localhost/Dt/namespace/com/practice/Bar.php
*/
namespace Com\Practice;

require_once '../sample/Hoge.php';

//名前空間違うから呼び出せない
//Fatal errpr: Class 'Com¥sample¥Practice¥Hoge' not found
//$hoge = new Hoge();

//フルパスで行けばOK
//冒頭の¥がないと相対パスになる
$hoge = new \Com\sample\Hoge;

class Bar{
  public function __construct()
  {
    echo "this is bar class";
  }
}
