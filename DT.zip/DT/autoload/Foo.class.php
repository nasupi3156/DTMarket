<?php
/*
 *ファイルパス : C:¥mamp¥htdocs¥DT¥autoload¥Foo.class.php
 *ファイル名 : Foo.class.php
 */

 class Foo{
  // fooを定義して、constructを定義、インスタンス化させたときに定義される
  public function __construct()
  {
    echo "Foo<br>";
  }
 }
//  public function __constructで一つで定義してます。
// fooクラスを用いてインスタンス化したとき
// インスタンス化
?>