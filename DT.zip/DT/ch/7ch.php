<?php

namespace ch;

require_once dirname(__FILE__).'/Bootstrap.php';
// Bootstrap.phpファイルを指定

use ch\Bootstrap;
//useで指定

// インスタンス化が実行されたタイミングでオートロードが実行
$db = new Database(Bootstrap::DB_HOST, Bootstrap::DB_USER, Bootstrap::DB_PASS, Bootstrap::DB_NAME);

//Twigを表示するための設定(Twigファイルの配置場所や、キャッシュファイルの保存場所を指定。)
$loader = new \Twig_Loader_Filesystem(Bootstrap::TEMPLATE_DIR);
$twig = new \Twig_Environment($loader,[
'cache' =>Bootstrap::CACHE_DIR
]);
//twigのバージョンが2.7以降の場合は次のような書き方が推奨される
//$loader = new\twig\loader\FilesystemLoader(Bootstrap::TEMPLATE_DIR);
//$twig = new \Twig\Enviroment($loader , [
//  'cache' => Bootstrap::CACHE_DIR
// ]};

$msg = '';
$err_msg = '';
if(isset($_POST['send']) === true) {
  $name = $_POST['name'];
  $contents = $_POST['contents'];

  if($name !== '' && $contents !== '') {
    $query = "INSERT INTO ch("
      ." name,"
      ." contents"
      .")VALUES("
      .$db->str_quote($name).","
      .$db->str_quote($contents).")";

      $res = $db->execute($query);

      if ($res !== false) {
        $msg = '書き込みに成功しました';
      } else {
        $err_msg = '書き込みに失敗しました';
      }
  } else {
    $err_msg = '名前とコメントを記入してください';
  }
}
// sql文を作ってるだけでそれを入れてる
$query = "SELECT"
        . " id,"
        ." name,"
        ." contents"
        ." FROM"
        ." ch";

$data = $db->select($query);
// $data : データベースからとってきた情報が入っている
$db->close();


//変数の設定
//twigファイルにデータに出力するための設定
$context = [];
//ここのmsgとtwigのmsgを使うことで取り出せる 
$context['msg'] = $msg;
$context['err_msg'] = $err_msg;
$context['data'] = $data;
//このdataはdatabaseからとってきた値
// まずtwigで出力するものは配列で入れる
//データ($context)を渡して、指定したTwigファイル(board5.html.twig)を表示

// 出力メソッド
$template = $twig->loadTemplate('7ch.html.twig');
$template -> display($context);
//下記のような記述でも可
//echo $twig->render('board.html.twig',$data);